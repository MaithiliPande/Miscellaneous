package filedemo;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileSample {

	public static void main(String[] args) throws IOException {
		File file1= new File("test.txt");
//		System.out.println(file1.exists());
//		boolean newFile=false;
//		try {
//			newFile = file1.createNewFile();
//			System.out.println(newFile);
//			System.out.println(file1.exists());
//		} catch (IOException e) {
//			System.out.println(e.getMessage());
//		}
		
		
//		FileWriter fw = new FileWriter(file1);
//		fw.write("This is a test file\nThis is demo.");
//		fw.flush();
//		fw.close();
		
		char[] cbuf = new char[50];
		FileReader fr = new FileReader(file1);
		fr.read(cbuf);
		for (char c : cbuf) {
			System.out.print(c);
			
		}
		fr.close();
		

	}

}
