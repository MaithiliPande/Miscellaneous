package com.yash.jdbcdemo.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;



public class DeleteDemo {
	private static Logger logger= Logger.getLogger(DeleteDemo.class);
	public static void main(String[] args)  {
		//1.Gather DB information
		String driverClassName="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://localhost/mydb";
		String user="root";
		String pwd="root";
		
		//2.Load driver or register driver
	
		try {
			Class c = Class.forName(driverClassName);
			logger.info("Class:-"+c);
			//3. Create connection object
			Connection con=DriverManager.getConnection(url, user, pwd);//java.sql connection 
			logger.info("con:-"+con);
			//4. create statement and execute query
			Statement stmt=con.createStatement();
			String sql="delete from contact where id='5'";
			stmt.executeUpdate(sql);
			logger.info(stmt);
			logger.info("record has been deleted successfully..checkDB");
			//5.close statement and connection
			stmt.close();
			con.close();
		
		} catch (Exception e) {
			logger.error("error"+e.getMessage());
		}
		
		
		
		
		
		
		
	}
	


}
