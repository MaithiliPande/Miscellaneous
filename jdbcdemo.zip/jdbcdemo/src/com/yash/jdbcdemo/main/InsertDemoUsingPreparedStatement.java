package com.yash.jdbcdemo.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;



public class InsertDemoUsingPreparedStatement {
	private static Logger logger= Logger.getLogger(InsertDemoUsingPreparedStatement.class);
	public static void main(String[] args)  {
		//1.Gather DB information
		String driverClassName="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://localhost/mydb";
		String user="root";
		String pwd="root";
		
		//2.Load driver or register driver
	
		try {
			Class c = Class.forName(driverClassName);
			logger.info("Class:-"+c);
			//3. Create connection object
			Connection con=DriverManager.getConnection(url, user, pwd);//java.sql connection 
			logger.info("con:-"+con);
			//4. create query, create preparedStatement, set placeholder value
			String sql="insert into contact(name,phone) values(?,?)";
			PreparedStatement pstmt=con.prepareStatement(sql);
			pstmt.setString(1, "Jon's");
			pstmt.setString(2, "9768594256");
			pstmt.execute();
			logger.info("record has been inserted successfully..checkDB");
			//5.close statement and connection
			pstmt.close();
			con.close();
		
		} catch (Exception e) {
			logger.error("error"+e.getMessage());
		}
		
		
		
		
		
		
		
	}
	


}
