package com.yash.jdbcdemo.main;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;



public class DataBaseMetaData {
	private static Logger logger= Logger.getLogger(DataBaseMetaData.class);
	public static void main(String[] args)  {
		//1.Gather DB information
		String driverClassName="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://localhost/mydb";
		String user="root";
		String pwd="root";
		
		//2.Load driver or register driver
	
		try {
			Class c = Class.forName(driverClassName);
			logger.info("Class:-"+c);
			//3. Create connection object
			Connection con=DriverManager.getConnection(url, user, pwd);//java.sql connection 
			logger.info("con:-"+con);
			//4. create statement and execute query
			DatabaseMetaData dbmd=con.getMetaData();
			
			System.out.println("Vendor name: "+dbmd.getDatabaseProductName());
			System.out.println("Version name:"+dbmd.getDatabaseProductVersion());
			System.out.println("User name:"+dbmd.getUserName());
			System.out.println("Driver name:"+dbmd.getDriverName());
			logger.info("record has been displayed successfully..checkDB");
			//5.close statement and connection
			
			con.close();
		
		} catch (Exception e) {
			logger.error("error"+e.getMessage());
		}
		
		
		
		
		
		
		
	}
	


}
