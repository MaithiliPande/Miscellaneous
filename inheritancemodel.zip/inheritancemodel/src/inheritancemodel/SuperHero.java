package inheritancemodel;

public class SuperHero {
	private String name;
	String suite="short suite";
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void fight() {
		System.out.println(getName()+" is fighting");
		
	}
	public void putOnSuite()
	{
		System.out.println(getName()+" is putting on "+suite);
		
	}
	public SuperHero(String name)
	{
		this.name=name;
		
	}
}
