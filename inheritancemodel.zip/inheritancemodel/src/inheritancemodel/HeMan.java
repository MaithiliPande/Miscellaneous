package inheritancemodel;

public class HeMan extends SuperHero {

	public HeMan(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	
	
	}

	
	


