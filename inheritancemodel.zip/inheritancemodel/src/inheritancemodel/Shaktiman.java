package inheritancemodel;

public class Shaktiman extends SuperHero {
	public Shaktiman(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	String suite="longSuite";
	public void putOnSuite(){
		System.out.println("");
		System.out.println(getName()+" is putting on "+suite);
	}
	public void rotate() {
		System.out.println(getName()+" is rotating");
	}
	

}
