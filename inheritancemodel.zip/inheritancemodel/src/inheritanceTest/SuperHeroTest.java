package inheritanceTest;

import inheritancemodel.HeMan;
import inheritancemodel.Shaktiman;

public class SuperHeroTest {

	public static void main(String[] args) {
		HeMan hm=new HeMan("Dharmendra");
		hm.putOnSuite();
		hm.fight();
		
		Shaktiman sm=new Shaktiman("Gangadhar");
		sm.putOnSuite();
		sm.rotate();
		sm.fight();
		

	}

}
