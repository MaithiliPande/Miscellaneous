package com.yash.serviceimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.yash.connection.DbConnection;
import com.yash.dto.Trainer;
import com.yash.dto.User;
/**
 * This is service class for the application.
 * @author maithili.pande
 *
 */

public class ApplicationService implements com.yash.service.ApplicationService {
	
		DbConnection connection= new DbConnection();
		/**
		 * This method provides user to insert record in userdetail table.
		 */
		public void insertUser(User usr)
		{
			Connection con=connection.getConnection();
			try {
				String sql="insert into userdetail(firstName,lastName,email,contact,status,role,userName,password) values(?,?,?,?,?,?,?,?)";
				PreparedStatement pstmt=con.prepareStatement(sql);
				pstmt.setString(1, usr.getFirstName());
				pstmt.setString(2, usr.getLastName());
				pstmt.setString(3, usr.getEmail());
				pstmt.setString(4, usr.getContact());
				pstmt.setString(5, usr.getStatus().getValue());
				pstmt.setString(6, usr.getRole().getValue());
				pstmt.setString(7, usr.getUserName());
				pstmt.setString(8, usr.getPassword());
				pstmt.execute();
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}

		/**
		 * This method lists all the record from userdetail table.
		 */
		public void listUsers()
		{
			Connection con=connection.getConnection();
			try {
				String sql="select * from userdetail";
				PreparedStatement pstmt=con.prepareStatement(sql);
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					int id=rs.getInt("id");
					String fName=rs.getString("firstName");
					String lName=rs.getString("lastName");
					String mail=rs.getString("email");
					String uContact=rs.getString("contact");
					String uStatus=rs.getString("status");
					String uRole=rs.getString("role");
					System.out.println("Id:"+id+"  Name:"+fName+" "+lName+"  Email:"+mail+"  Contact:"+uContact+"  Status:"+uStatus+"  Role:"+uRole);
				}
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		/**
		 * This method provides admin to update status of the user. It takes id and status as its parameters.
		 */
		public void updateStatus(int uId, String uStatus) {
			Connection con=connection.getConnection();
			try {
				String sql="update userdetail set status='"+uStatus+"'where id='"+uId+"'";
				PreparedStatement pstmt=con.prepareStatement(sql);
				pstmt.executeUpdate();
				System.out.println("updated");
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		/**
		 * This method provides admin to update role of the user. It takes id and role as its parameters.
		 */
		public void updateRole(int uId, String uRole) {
			Connection con=connection.getConnection();
			try {
				String sql="update userdetail set role='"+uRole+"'where id='"+uId+"'";
				PreparedStatement pstmt=con.prepareStatement(sql);
				pstmt.executeUpdate();
				System.out.println("updated");
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
						
		}
		
		/**
		 * This method provides user to list data about trainees.
		 */
		public void listTrainee() {
			Connection con=connection.getConnection();
			try {
				String sql="select * from userdetail where role='trainee'";
				PreparedStatement pstmt=con.prepareStatement(sql);
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					int id=rs.getInt("id");
					String fName=rs.getString("firstName");
					String lName=rs.getString("lastName");
					String mail=rs.getString("email");
					String uContact=rs.getString("contact");
					String uStatus=rs.getString("status");
					String uRole=rs.getString("role");
					System.out.println("Id:"+id+"  Name:"+fName+" "+lName+"  Email:"+mail+"  Contact:"+uContact+"  Status:"+uStatus+"  Role:"+uRole);
				}
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		/**
		 * This method provides trainer to add new course.
		 */
		public void addCourse(Trainer trainr){
			Connection con=connection.getConnection();
			try {
				String sql="insert into course(courseName) values(?)";
				PreparedStatement pstmt=con.prepareStatement(sql);
				pstmt.setString(1, trainr.getCourseName());
				pstmt.execute();
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		/**
		 * This method provides user to list all the courses.
		 */
		public void listcourse() {
			Connection con=connection.getConnection();
			try {
				String sql="select * from course";
				PreparedStatement pstmt=con.prepareStatement(sql);
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					int id=rs.getInt("courseId");
					String courseName=rs.getString("courseName");
					System.out.println("Id:"+id+"  Course Name:"+courseName);
				}
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		/**
		 * This method provides trainer to update course. It takes id and course name as its parameters.
		 */
		public void updateCourse(int cId, String courseName)
		{
			Connection con=connection.getConnection();
			try {
				String sql="update course set courseName='"+courseName+"'where courseId='"+cId+"'";
				PreparedStatement pstmt=con.prepareStatement(sql);
				pstmt.executeUpdate();
				System.out.println("updated");
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		/**
		 * This method provides functionality to trainer to delete the courses.
		 */
		public void deleteCourse(int courseId) {
			Connection con=connection.getConnection();
			try {
				String sql="delete from course where courseId='"+courseId+"'";
				PreparedStatement pstmt=con.prepareStatement(sql);
				pstmt.executeUpdate();
				System.out.println("updated");
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		/**
		 * This method provides functionality to trainee to read the course.
		 */
		public void readCourse(int cId) {
			Connection con=connection.getConnection();
			try {
				String sql="select * from course where courseId='"+cId+"'";
				PreparedStatement pstmt=con.prepareStatement(sql);
				ResultSet rs=pstmt.executeQuery();
				while(rs.next())
				{
					String courseName=rs.getString("courseName");
					System.out.println("Your are reading  Course:"+courseName);
				}
				pstmt.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
}

