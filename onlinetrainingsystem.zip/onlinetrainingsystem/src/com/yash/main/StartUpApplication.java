package com.yash.main;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.yash.connection.DbConnection;
import com.yash.dto.Login;
import com.yash.dto.User;
import com.yash.serviceimpl.ApplicationService;
import com.yash.utility.AdminMenu;
import com.yash.utility.TraineeMenu;
import com.yash.utility.TrainerMenu;
/**
 * This is main class for this application.
 * @author maithili.pande
 *
 */
public class StartUpApplication {

	public static void main(String[] args) {
		ApplicationService service=new ApplicationService();
		Login login=new Login();
		Scanner sc=new Scanner(System.in);
		int choice;
		String continueChoice;
		do
		{
			System.out.println("---Menu---");
			System.out.println("1. Login");
			System.out.println("2. Register");
			System.out.print("Enter your choice:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				login(service, sc);
				break;
			case 2:
				registration(service, sc);
				break;
			default:
				System.out.println("Invalid choice");
				break;
			}
			
		}while(true);
	
	}

	/**
	 * This method provides user to register for the application.
	 * @param service
	 * @param sc
	 */
	public static void registration(ApplicationService service, Scanner sc) {
		User user=new User();
		System.out.println("\nEnter firstName");
		String regFName=sc.next();
		user.setFirstName(regFName);
		System.out.println("Enter lastName");
		String regLName=sc.next();
		user.setLastName(regLName);
		System.out.println("Enter email address");
		String regEmail=sc.next();
		user.setEmail(regEmail);
		System.out.println("Enter contact");
		String regContact=sc.next();
		user.setContact(regContact);
		System.out.println("Enter user name");
		String regUser=sc.next();
		user.setUserName(regUser);
		System.out.println("Enter password");
		String regPwd=sc.next();
		user.setPassword(regPwd);
		service.insertUser(user);
		System.out.println("data inserted");
	}

	/**
	 * This login method checks role and status of user and provides access to application.
	 * @param service
	 * @param sc
	 */
	public static void login(ApplicationService service, Scanner sc) {
		DbConnection connection= new DbConnection();
		Connection con=connection.getConnection();
		System.out.println("\nEnter user name:");
		String usrName=sc.next();
		System.out.println("Enter password:");
		String usrPassword=sc.next();
		try {
			String role=null;
			String status=null;
			String fName=null;
			String lName=null;
			String sql="select * from userdetail where userName='"+usrName+"' and password='"+usrPassword+"'";
			PreparedStatement pstmt=con.prepareStatement(sql);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next())
			{
				role=rs.getString("role");
				status=rs.getString("status");
				fName=rs.getString("firstName");
				lName=rs.getString("lastName");
			}
			if(role.equalsIgnoreCase("admin") && status.equalsIgnoreCase("active"))
			{
				System.out.println("Welcome "+fName+" "+lName+" to admin page");
				AdminMenu admin=new AdminMenu();
				admin.adminMenu(usrName,usrPassword);
			}
			else if(role.equalsIgnoreCase("trainer") && status.equalsIgnoreCase("active"))
			{
				System.out.println("Welcome "+fName+" "+lName+" to trainer page");
				TrainerMenu trainer=new TrainerMenu();
				trainer.trainerMenu(usrName, usrPassword);
			}
			else if(role.equalsIgnoreCase("trainee") && status.equalsIgnoreCase("active"))
			{
				System.out.println("Welcome "+fName+" "+lName+" to trainee page");
				TraineeMenu trainee=new TraineeMenu();
				trainee.traineeMenu(usrName, usrPassword);
			}
			pstmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		
	}

}
