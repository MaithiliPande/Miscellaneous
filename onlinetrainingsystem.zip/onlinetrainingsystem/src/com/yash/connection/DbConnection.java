package com.yash.connection;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

/**
 * This class provides functionality to get the connection of database. 
 * config.properties file contains details about the driver class, url, user and password.
 * @author maithili.pande
 *
 */
public class DbConnection {
	
	public Connection getConnection() {
		Connection con=null;
		try {
			File file = new File("config.properties");
			FileInputStream fileInput = new FileInputStream(file);
			Properties properties = new Properties();
			properties.load(fileInput);
			String driverClassName=properties.getProperty("driverClassName");
			String url=properties.getProperty("url");
			String user=properties.getProperty("user");
			String pwd=properties.getProperty("pwd");
			Class c = Class.forName(driverClassName);
			con=DriverManager.getConnection(url, user, pwd);
			return con;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}

}
