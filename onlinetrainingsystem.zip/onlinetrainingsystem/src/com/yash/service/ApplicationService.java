package com.yash.service;

import com.yash.dto.Trainer;
import com.yash.dto.User;

public interface ApplicationService {
	
	public void insertUser(User u);
	public void listUsers();
	public void updateStatus(int uId, String uStatus);
	public void updateRole(int uId, String uRole);
	public void listTrainee() ;
	public void addCourse(Trainer trainr);
	public void listcourse();
	public void updateCourse(int cId, String courseName);
	public void deleteCourse(int courseId);
	public void readCourse(int cId);

}
