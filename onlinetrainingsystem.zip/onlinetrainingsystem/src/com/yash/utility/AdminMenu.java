package com.yash.utility;

import java.util.Scanner;

import com.yash.serviceimpl.ApplicationService;
/**
 * This class provides functionality to admin user to access details of any user and change their status and role. 
 * @author maithili.pande
 *
 */
public class AdminMenu {
	Scanner sc=new Scanner(System.in);
	ApplicationService service=new ApplicationService();
	public void adminMenu(String uName, String uPwd)
	{
		int choice;
		String continueChoice;
			
			System.out.println(" ");
			do
			{
				System.out.println("Menu");
				System.out.println("1. List users");
				System.out.println("2. Set role");
				System.out.println("3. Change user status");
				System.out.println("4. Logout");
				System.out.print("\nEnter your choice: ");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:
					service.listUsers();
					break;
				case 2:
					System.out.println("Enter user id");
					int uIdRole=sc.nextInt();
					System.out.println("Enter role to change");
					String uRole=sc.next();
					service.updateRole(uIdRole,uRole);
					break;
				case 3:
					System.out.println("Enter user id");
					int uId=sc.nextInt();
					System.out.println("Enter status to change");
					String uStatus=sc.next();
					service.updateStatus(uId,uStatus);
					break;
				case 4:
					System.out.println("You logged out!");
					return;
				default:System.out.println("Invalid choice");
						break;
				}
				
			}while(true);
	}
}
