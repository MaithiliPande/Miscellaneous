package com.yash.utility;

import java.util.Scanner;

import com.yash.dto.Trainer;
import com.yash.serviceimpl.ApplicationService;
/**
 * This class provides user to access details about the trainees and courses.
 * @author maithili.pande
 *
 */
public class TrainerMenu {
	Scanner sc=new Scanner(System.in);
	ApplicationService service=new ApplicationService();
	public void trainerMenu(String uName, String uPwd)
	{
		int choice;
		String continueChoice;
			System.out.println(" ");
			do
			{
				System.out.println("Menu");
				System.out.println("1. List trainees");
				System.out.println("2. Add course");
				System.out.println("3. List course");
				System.out.println("4. Delete course");
				System.out.println("5. Update Course");
				System.out.println("6. Logout");
				System.out.print("\nEnter your choice: ");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:
					service.listTrainee();
					break;
				case 2:
					Trainer trainr=new Trainer();
					System.out.println("Enter course name:");
					String cName=sc.next();
					trainr.setCourseName(cName);
					service.addCourse(trainr);
					break;
				case 3:
					service.listcourse();
					break;
				case 4:
					System.out.println("Enter course id to delete:");
					int courseId=sc.nextInt();
					service.deleteCourse(courseId);
					break;
				case 5:
					System.out.println("Enter course id to update course");
					int cId=sc.nextInt();
					System.out.println("Enter course name");
					String courseName=sc.next();
					service.updateCourse(cId,courseName);
					break;
				case 6:
					System.out.println("You logged out!");
					return;
				default:System.out.println("Invalid choice");
						break;
				}
				
			}while(true);
	}

}
