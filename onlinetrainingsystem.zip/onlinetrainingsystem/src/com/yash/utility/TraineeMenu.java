package com.yash.utility;

import java.util.Scanner;
import com.yash.serviceimpl.ApplicationService;
/**
 * This class provides functionality to trainee to access the courses.
 * @author maithili.pande
 *
 */
public class TraineeMenu {
	Scanner sc=new Scanner(System.in);
	ApplicationService service=new ApplicationService();
	public void traineeMenu(String uName, String uPwd)
	{
		int choice;
		String continueChoice;
			System.out.println(" ");
			do
			{
				System.out.println("Menu");
				System.out.println("1. List course");
				System.out.println("2. Read course");
				System.out.println("3. Logout");
				System.out.print("\nEnter your choice: ");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:
					service.listcourse();
					break;
				case 2:
					System.out.println("Enter course id to read:");
					int cId=sc.nextInt();
					service.readCourse(cId);
					break;
				case 3:
					System.out.println("You logged out!");
					return;
				default:System.out.println("Invalid choice");
						break;
				}
			}while(true);
	}
}
