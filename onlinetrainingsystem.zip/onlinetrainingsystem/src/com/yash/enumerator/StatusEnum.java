package com.yash.enumerator;
/**
 * This is enumerator with name StatusEnum which has fixed set of constants PENDING, ACTIVE, INACTIVE and DELETED.
 * @author maithili.pande
 *
 */
public enum StatusEnum {
	PENDING("pending"),ACTIVE("active"),INACTIVE("inactive"),DELETED("deleted");
	private String status;
	private StatusEnum(String s)
	{
		this.status=s;
	}
	public String getValue()
	{
		status=this.status;
		return status;
	}
	

	
}
