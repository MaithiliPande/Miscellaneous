package com.yash.enumerator;
/**
 * This is enumerator with name RoleEnum which has fixed set of constants ADMIN,TRAINER and TRAINEE.
 * @author maithili.pande
 *
 */
public enum RoleEnum {
	ADMIN("Admin"),TRAINER("Trainer"),TRAINEE("Trainee");

	private String role;
	private RoleEnum(String role)
	{
		this.role=role;
	}
	public String getValue()
	{
		role=this.role;
		return role;
	}

}
