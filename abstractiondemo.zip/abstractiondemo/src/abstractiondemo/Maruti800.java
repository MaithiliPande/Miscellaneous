package abstractiondemo;

public class Maruti800 extends Car{
	public void drive() {
		System.out.println("Drive with normal steering");
	}
	public void stop() {
		System.out.println("stop by normal brake");
	}

}
