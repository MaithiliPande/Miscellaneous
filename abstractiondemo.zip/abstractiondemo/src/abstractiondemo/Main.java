package abstractiondemo;

public class Main {

	public static void main(String[] args) {
		Car driver;
		driver=new Safari();
		driver.drive();
		driver.stop();
		driver.fillTank();
		
		

	}

}
