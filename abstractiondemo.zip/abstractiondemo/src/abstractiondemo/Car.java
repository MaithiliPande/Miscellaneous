package abstractiondemo;

public abstract class Car {
	//Abstract features of incomplete feature
	public abstract void drive();	//drive through steering
	public abstract void stop();	//stop by brake
	
	//default or complete feature
	public void fillTank()
	{
		System.out.println("Fullling car..");
	}
	public void playingMusic()
	{
		System.out.println(" music is playing.....");
	}
	
	
	

}
