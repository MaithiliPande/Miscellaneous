package abstractiondemo;

public class Safari extends Car {
	public void drive() {
		System.out.println("Drive with power steering");
	}
	public void stop() {
		System.out.println("stop by power brake");
	}

}
