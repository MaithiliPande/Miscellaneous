package userinputemployee;
/**
 * This is a start up class for the application.
 */
import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class EmployeeTestInput {

	public static void main(String[] args) throws IOException {
		int choice;
		String continueChoice;
		Employee empScanner= new Employee();
		System.out.println("Enter 1: To input using Scanner Class\n2: To input using JOption Pane\n3: To input using Command Prompt\n4: To input using Buffered Reader\n5:To Exit");
		@SuppressWarnings("resource")
		Scanner input=new Scanner(System.in);
		choice=input.nextInt();
		do
		{
				switch(choice)
				{
				case 1:
					System.out.println("Enter employee's Id:");
					int id=input.nextInt();
					empScanner.setEmpId(id);
					System.out.println("Enter employee's Name:");
					String name=input.next();
					empScanner.setEmpName(name);
					System.out.println("Enter employee's Salary:");
					int salary=input.nextInt();
					empScanner.setEmpSalary(salary);
					
					System.out.println("Employee Id:"+empScanner.getEmpId());
					System.out.println("Employee name:"+empScanner.getEmpName());
					System.out.println("Employee Salary:"+empScanner.getEmpSalary());
				
					break;
				case 2:
					Employee empJoption= new Employee();
					int jOptionId=Integer.parseInt(JOptionPane.showInputDialog("Enter Employee's Id:"));
					empJoption.setEmpId(jOptionId);
					String jOptionName=JOptionPane.showInputDialog("Enter Employee's Name:");
					empJoption.setEmpName(jOptionName);
					int jOptionSalary=Integer.parseInt(JOptionPane.showInputDialog("Enter Employee's Salary:"));
					empJoption.setEmpSalary(jOptionSalary);
					
					System.out.println("Employee Id:"+empJoption.getEmpId());
					System.out.println("Employee name:"+empJoption.getEmpName());
					System.out.println("Employee Salary:"+empJoption.getEmpSalary());
					break;
				case 3:
					
					Employee empCon= new Employee();
					System.out.println("Enter Employee's Id:");
					int consoleId=Integer.parseInt(System.console().readLine());
					empCon.setEmpId(consoleId);
					System.out.println("Enter Employee's Name:");
					String consoleName=System.console().readLine();
					empCon.setEmpName(consoleName);
					System.out.println("Enter Employee's Salary:");
					int consoleSalary=Integer.parseInt(System.console().readLine());
					empCon.setEmpSalary(consoleSalary);
					
					System.out.println("Employee Id:"+empCon.getEmpId());
					System.out.println("Employee name:"+empCon.getEmpName());
					System.out.println("Employee Salary:"+empCon.getEmpSalary());
					break;
				case 4:
					Employee empBuf= new Employee();
					InputStreamReader r= new InputStreamReader(System.in);
					BufferedReader bf= new BufferedReader(r);
					int bufId;
					String bufName;
					int bufSalary;
					System.out.println("Enter Employee's Id:");
					bufId=Integer.parseInt(bf.readLine());
					empBuf.setEmpId(bufId);
					System.out.println("Enter Employee's Name:");
					bufName=bf.readLine();
					empBuf.setEmpName(bufName);
					System.out.println("Enter Employee's Salary:");
					bufSalary=Integer.parseInt(bf.readLine());
					empBuf.setEmpSalary(bufSalary);
					
					System.out.println("Employee Id:"+empBuf.getEmpId());
					System.out.println("Employee name:"+empBuf.getEmpName());
					System.out.println("Employee Salary:"+empBuf.getEmpSalary());
					
					break;
				case 5:
					System.exit(0);
					break;
				default:
					System.out.println("Invalid input");
					break;
			}
				System.out.println("\nDo you want to continue : y/n");
				continueChoice=input.next();
		}
		while(continueChoice.equalsIgnoreCase("y"));
				
			

	}

}
