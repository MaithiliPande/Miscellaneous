package userinputemployee;
/**
 * This is class will represent data of an employee.
 * @author maithili.pande
 *
 */

public class Employee {
	private int empId;
	private String empName;
	private int empSalary;
	/**
	 * This will set employee's details by parameterised constructor
	 * @param empId
	 * @param empName
	 * @param empSalary
	 */
	
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}
	public int getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public int getEmpSalary() {
		return empSalary;
	}
	
	

}
