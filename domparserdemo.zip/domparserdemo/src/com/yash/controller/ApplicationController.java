package com.yash.controller;

public class ApplicationController {

}
