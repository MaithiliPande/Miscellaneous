package com.yash.pojo;

public class User {

}
