package com.yash.pojo;

public interface Pojo {

}
