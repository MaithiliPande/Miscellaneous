package com.yash.factory;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.yash.pojo.Application;

public class PojoFactory {
	private File xmlFile;

	public PojoFactory(File file) {
		this.xmlFile=file;
	}

	public Object getPojo(String inputString) throws ParserConfigurationException, SAXException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder= dbFactory.newDocumentBuilder();
		Document doc=dBuilder.parse(xmlFile);
		doc.getDocumentElement().normalize();
		System.out.println("Root element:"+doc.getDocumentElement().getNodeName());
		NodeList nList=doc.getElementsByTagName("pojo");
		System.out.println("---------------------------");
		
		for (int i = 0; i < nList.getLength(); i++) {
			Node nNode= nList.item(i);
			System.out.println("Node:"+nNode.getNodeName());
			if(nNode.getNodeType() == Node.ELEMENT_NODE)
			{
				Element eElement = (Element)nNode;
				String elementId=eElement.getAttribute("id");
				if(elementId.equalsIgnoreCase(inputString))
				{
					String className=eElement.getAttribute("class");
					Object object=Class.forName(className).newInstance();
					System.out.println(object);
					NodeList childList=doc.getElementsByTagName("property");
					for(int temp=0; temp< childList.getLength();temp++)
					{
						Node childNode = childList.item(temp);
						System.out.println("Child node:"+childNode.getNodeName());
					}
					
					 
				}
				System.out.println("");
				
			}
		}
		
	
		
		return null;
	}
	
	
	

}
