package com.yash.factory;

import java.io.File;

public class LoadPojoXml extends PojoFactory {

	public LoadPojoXml(File file) {
		super(file);
	}
	

}
