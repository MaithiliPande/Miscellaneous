package com.yash.main;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.yash.factory.LoadPojoXml;
import com.yash.factory.PojoFactory;
import com.yash.pojo.Application;

public class DOMParserStartUp {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		PojoFactory pf= new LoadPojoXml(new File("pojo.xml"));
		Application app= (Application)pf.getPojo("application");

	}

}
